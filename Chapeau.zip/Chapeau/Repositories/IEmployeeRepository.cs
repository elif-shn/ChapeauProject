﻿using Chapeau.Models;

namespace Chapeau.Repositories
{
    public interface IEmployeeRepository
    {
        List<Employee> GetAll();
        Employee GetById(int id);
        void Add(Employee employee);
        void Update(Employee employee);
        void SetActive(int id, bool isActive);
        bool EmployeeNumberExists(string employeeNumber); 
    }
}